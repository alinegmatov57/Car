package pdp;

public class Ali {
    public static void main(String[] args) {
        System.out.println("Ali");
    }
}
